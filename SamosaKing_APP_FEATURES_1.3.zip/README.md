# Samosa King – Nawalgarh

Version 1.3 source update: app logo, real Firebase Phone OTP login UI/integration, and Help Center (Call/WhatsApp).

Important: Firebase Console must have **Phone** sign-in enabled and the Android app SHA-1/SHA-256 configured for real OTP. No fake OTP is included.
