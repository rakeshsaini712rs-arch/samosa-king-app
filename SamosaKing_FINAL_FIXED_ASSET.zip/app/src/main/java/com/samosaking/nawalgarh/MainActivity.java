package com.samosaking.nawalgarh;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private WebView web; private FirebaseAuth auth; private FirebaseFirestore db;
  private FusedLocationProviderClient locationClient; private ListenerRegistration statusListener;
  private String pendingName,pendingPhone,pendingAddress,pendingItems; private int pendingSubtotal;
  
  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.setWebViewClient(new WebViewClient()); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); web.addJavascriptInterface(new AndroidBridge(),"AndroidBridge"); setContentView(web); auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance(); locationClient=LocationServices.getFusedLocationProviderClient(this); auth.signInAnonymously().addOnSuccessListener(r->runJs("window.authReady&&window.authReady();")); web.loadUrl("file:///android_asset/index.html");}
  private void runJs(String js){runOnUiThread(()->web.evaluateJavascript(js,null));}
  private void beginOrder(String n,String p,String a,String items,int sub){pendingName=n;pendingPhone=p;pendingAddress=a;pendingItems=items;pendingSubtotal=sub;if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},41);return;}createOrder();}
  private void createOrder(){if(auth.getCurrentUser()==null){runJs("window.orderError('Firebase sign-in failed.');");return;}int d=30,t=pendingSubtotal+d;CancellationTokenSource c=new CancellationTokenSource();locationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY,c.getToken()).addOnSuccessListener(l->writeOrder(l,t,d)).addOnFailureListener(e->writeOrder(null,t,d));}
  private void writeOrder(Location loc,int total,int delivery){try{Map<String,Object> o=new HashMap<>();o.put("userId",auth.getCurrentUser().getUid());o.put("customerName",pendingName);o.put("mobile",pendingPhone);o.put("address",pendingAddress);o.put("paymentMethod","COD");o.put("subtotal",pendingSubtotal);o.put("deliveryFee",delivery);o.put("total",total);o.put("status","PLACED");o.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());JSONArray arr=new JSONArray(pendingItems);Map<String,Object> items=new HashMap<>();for(int i=0;i<arr.length();i++){JSONObject x=arr.getJSONObject(i);items.put(x.getString("id"),x.getInt("qty"));}o.put("items",items);if(loc!=null){o.put("latitude",loc.getLatitude());o.put("longitude",loc.getLongitude());}db.collection("orders").add(o).addOnSuccessListener(r->{getPreferences(Context.MODE_PRIVATE).edit().putString("lastOrderId",r.getId()).apply();listenStatus(r.getId());runJs("window.orderCreated("+JSONObject.quote(r.getId())+");");}).addOnFailureListener(e->runJs("window.orderError("+JSONObject.quote(e.getMessage())+");"));}catch(Exception e){runJs("window.orderError("+JSONObject.quote(e.getMessage())+");");}}
  private void listenStatus(String id){if(statusListener!=null)statusListener.remove();statusListener=db.collection("orders").document(id).addSnapshotListener((s,e)->{if(e!=null||s==null||!s.exists())return;String st=s.getString("status");if(st==null)st="PLACED";runJs("window.statusUpdate("+JSONObject.quote(st)+");");});}
  @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==41)createOrder();}
  public class AndroidBridge{@JavascriptInterface public void placeOrder(String n,String p,String a,String i,int s){beginOrder(n,p,a,i,s);}@JavascriptInterface public void loadLastOrder(){String id=getPreferences(Context.MODE_PRIVATE).getString("lastOrderId",null);if(id!=null)listenStatus(id);}@JavascriptInterface public void cancelLastOrder(){String id=getPreferences(Context.MODE_PRIVATE).getString("lastOrderId",null);if(id!=null)db.collection("orders").document(id).update("status","CANCELLED");}}
}
