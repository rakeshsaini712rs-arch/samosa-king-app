package com.samosaking.nawalgarh;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
  private WebView web; private FirebaseAuth auth; private FirebaseFirestore db; private ListenerRegistration statusListener;
  private String pendingName,pendingPhone,pendingAddress,pendingItems; private int pendingSubtotal;
  private boolean orderInFlight=false;
  
  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.setWebViewClient(new WebViewClient()); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); web.addJavascriptInterface(new AndroidBridge(),"AndroidBridge"); setContentView(web); auth=FirebaseAuth.getInstance(); db=FirebaseFirestore.getInstance(); auth.signInAnonymously().addOnSuccessListener(r->runJs("window.authReady&&window.authReady();")); web.loadUrl("file:///android_asset/index.html");}
  private void runJs(String js){runOnUiThread(()->web.evaluateJavascript(js,null));}
  private void beginOrder(String n,String p,String a,String items,int sub){
    if(orderInFlight){runJs("window.orderError("+JSONObject.quote("Order already being submitted. Please wait.")+");");return;}
    orderInFlight=true;
    pendingName=n; pendingPhone=p; pendingAddress=a; pendingItems=items; pendingSubtotal=sub;
    if(sub<100){orderInFlight=false;runJs("window.orderError("+JSONObject.quote("Minimum order is ₹100.")+");");return;}
    createOrder();
  }
  private void createOrder(){
    if(auth.getCurrentUser()==null){
      auth.signInAnonymously()
        .addOnSuccessListener(r->writeOrder(pendingSubtotal+30,30))
        .addOnFailureListener(e->{orderInFlight=false;runJs("window.orderError("+JSONObject.quote("Firebase sign-in failed: "+e.getMessage())+");");});
      return;
    }
    writeOrder(pendingSubtotal+30,30);
  }
  private void writeOrder(int total,int delivery){try{Map<String,Object> o=new HashMap<>();o.put("userId",auth.getCurrentUser().getUid());o.put("customerName",pendingName);o.put("mobile",pendingPhone);o.put("address",pendingAddress);o.put("paymentMethod","COD");o.put("subtotal",pendingSubtotal);o.put("deliveryFee",delivery);o.put("total",total);o.put("status","PLACED");o.put("createdAt",com.google.firebase.firestore.FieldValue.serverTimestamp());JSONArray arr=new JSONArray(pendingItems);Map<String,Object> items=new HashMap<>();for(int i=0;i<arr.length();i++){JSONObject x=arr.getJSONObject(i);items.put(x.getString("id"),x.getInt("qty"));}o.put("items",items);db.collection("orders").add(o).addOnSuccessListener(r->{getPreferences(Context.MODE_PRIVATE).edit().putString("lastOrderId",r.getId()).apply();listenStatus(r.getId());orderInFlight=false;runJs("window.orderCreated("+JSONObject.quote(r.getId())+");");}).addOnFailureListener(e->{orderInFlight=false;runJs("window.orderError("+JSONObject.quote("Order save failed: "+e.getMessage())+");");});}catch(Exception e){orderInFlight=false;runJs("window.orderError("+JSONObject.quote("Order preparation failed: "+e.getMessage())+");");}}
  private void listenStatus(String id){if(statusListener!=null)statusListener.remove();statusListener=db.collection("orders").document(id).addSnapshotListener((s,e)->{if(e!=null||s==null||!s.exists())return;String st=s.getString("status");if(st==null)st="PLACED";runJs("window.statusUpdate("+JSONObject.quote(st)+");");});}
  public class AndroidBridge{@JavascriptInterface public void placeOrder(String n,String p,String a,String i,int s){beginOrder(n,p,a,i,s);}@JavascriptInterface public void loadLastOrder(){String id=getPreferences(Context.MODE_PRIVATE).getString("lastOrderId",null);if(id!=null)listenStatus(id);}@JavascriptInterface public void cancelLastOrder(){String id=getPreferences(Context.MODE_PRIVATE).getString("lastOrderId",null);if(id!=null)db.collection("orders").document(id).update("status","CANCELLED");}}
}
