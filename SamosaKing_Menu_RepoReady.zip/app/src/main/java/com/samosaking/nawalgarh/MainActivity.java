package com.samosaking.nawalgarh;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private FusedLocationProviderClient locationClient;
    private ListenerRegistration statusListener;
    private String pendingName, pendingPhone, pendingAddress, pendingItems;
    private int pendingSubtotal;
    private boolean requestingLocation = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setWebViewClient(new WebViewClient());
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        setContentView(web);
        auth = FirebaseAuth.getInstance(); db = FirebaseFirestore.getInstance();
        locationClient = LocationServices.getFusedLocationProviderClient(this);
        auth.signInAnonymously().addOnSuccessListener(r -> runJs("window.authReady && window.authReady();"));
        web.loadUrl("file:///android_asset/index.html");
    }

    private void runJs(String js) { runOnUiThread(() -> web.evaluateJavascript(js, null)); }

    private void beginOrder(String name, String phone, String address, String itemsJson, int subtotal) {
        pendingName=name; pendingPhone=phone; pendingAddress=address; pendingItems=itemsJson; pendingSubtotal=subtotal;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 41);
            requestingLocation = true; return;
        }
        createOrderWithLocation();
    }

    private void createOrderWithLocation() {
        if (auth.getCurrentUser() == null) { runJs("window.orderError('Firebase sign-in failed.');"); return; }
        int delivery=30, total=pendingSubtotal+delivery;
        CancellationTokenSource cts = new CancellationTokenSource();
        locationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.getToken())
            .addOnSuccessListener(loc -> writeOrder(loc, total, delivery))
            .addOnFailureListener(e -> writeOrder(null, total, delivery));
    }

    private void writeOrder(Location loc, int total, int delivery) {
        try {
            Map<String,Object> order = new HashMap<>();
            order.put("userId", auth.getCurrentUser().getUid());
            order.put("customerName", pendingName); order.put("mobile", pendingPhone);
            order.put("address", pendingAddress); order.put("paymentMethod", "COD");
            order.put("subtotal", pendingSubtotal); order.put("deliveryFee", delivery); order.put("total", total);
            order.put("status", "PLACED"); order.put("createdAt", com.google.firebase.firestore.FieldValue.serverTimestamp());
            JSONArray arr = new JSONArray(pendingItems); Map<String,Object> items = new HashMap<>();
            for(int i=0;i<arr.length();i++){ JSONObject x=arr.getJSONObject(i); items.put(x.getString("id"), x.getInt("qty")); }
            order.put("items", items);
            if(loc != null){ order.put("latitude", loc.getLatitude()); order.put("longitude", loc.getLongitude()); }
            db.collection("orders").add(order).addOnSuccessListener(ref -> {
                getPreferences(Context.MODE_PRIVATE).edit().putString("lastOrderId", ref.getId()).apply();
                listenStatus(ref.getId());
                runJs("window.orderCreated("+JSONObject.quote(ref.getId())+");");
            }).addOnFailureListener(e -> runJs("window.orderError("+JSONObject.quote(e.getMessage())+");"));
        } catch(Exception e){ runJs("window.orderError("+JSONObject.quote(e.getMessage())+");"); }
    }

    private void listenStatus(String id){
        if(statusListener!=null) statusListener.remove();
        statusListener=db.collection("orders").document(id).addSnapshotListener((snap,e)->{
            if(e!=null || snap==null || !snap.exists()) return;
            String status=snap.getString("status"); if(status==null) status="PLACED";
            runJs("window.statusUpdate("+JSONObject.quote(status)+");");
        });
    }

    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){
        super.onRequestPermissionsResult(req,p,g);
        if(req==41){ requestingLocation=false; createOrderWithLocation(); }
    }

    public class AndroidBridge {
        @JavascriptInterface public void placeOrder(String name,String phone,String address,String itemsJson,int subtotal){ beginOrder(name,phone,address,itemsJson,subtotal); }
        @JavascriptInterface public void loadLastOrder(){ String id=getPreferences(Context.MODE_PRIVATE).getString("lastOrderId",null); if(id!=null) listenStatus(id); }
        @JavascriptInterface public void cancelLastOrder(){ String id=getPreferences(Context.MODE_PRIVATE).getString("lastOrderId",null); if(id==null)return; db.collection("orders").document(id).update("status","CANCELLED"); }
    }
}
